<?php helper('url'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Tasks for Today Management System">
    <title><?= esc($title) ?> | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('assets/style.css') ?>">
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?= site_url('/') ?>"><span class="brand-mark">✓</span> Tasks for Today</a>
    <span class="course">IT0049 · Web System Technologies</span>
</header>
<div class="shell">
    <aside>
        <p class="eyebrow">WORKSPACE</p>
        <nav aria-label="Main navigation">
            <?php foreach (['welcome' => ['/', 'Welcome'], 'tasks' => ['tasks', 'Task List'], 'profile' => ['profile', 'Profile'], 'about' => ['about', 'About']] as $key => $item): ?>
                <a class="nav-item <?= $active === $key ? 'selected' : '' ?>" <?= $active === $key ? 'aria-current="page"' : '' ?> href="<?= site_url($item[0]) ?>"><?= esc($item[1]) ?></a>
            <?php endforeach ?>
        </nav>
        <div class="sidebar-note">A clearer view of<br>what needs doing.</div>
    </aside>
    <main id="main"><?= $this->renderSection('content') ?></main>
</div>
<footer>Tasks for Today Management System <span>CodeIgniter 4 · IT0049 TSA1</span></footer>
</body>
</html>
