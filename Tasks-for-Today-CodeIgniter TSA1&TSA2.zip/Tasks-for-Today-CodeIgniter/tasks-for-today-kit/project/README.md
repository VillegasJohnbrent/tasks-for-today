# Tasks for Today Management System

IT0049 — Technical Summative Assessment 1. A CodeIgniter 4 application with a
MySQL/MariaDB database and four pages.

## Developer and submission

- Developer: John — replace with your full name.
- Section: replace with your section.
- Repository URL: add your GitHub URL.
- Hosted URL: add your working application URL.

Set the developer name and section in `.env` as well; those values appear on About.

## Features and requirements

| Route | Behavior |
|---|---|
| `/` | Welcome: only records whose task_date equals today in Asia/Manila |
| `/tasks` | All tasks, ordered by task_date ascending and then id ascending |
| `/profile` | The one demo user from the users table |
| `/about` | Static project/developer information; no database query |

- TaskModel and UserModel contain database retrieval logic.
- Dashboard controller passes records to views.
- Shared layout and task table; responsive CSS with no external assets.
- Database output is escaped in views.
- SQL uses the exact assessment schema, 9 tasks over 3 dates, and 1 demo user.
- Scope: listing/display only. The assessment does not require login or task editing.

## Local setup

Requires PHP compatible with the installed CodeIgniter release, Composer,
MySQL/MariaDB, and the framework's required PHP extensions (including intl,
mbstring, and mysqli for this database). Composer validates its platform requirements.

If you used INSTALL-WINDOWS.bat, dependencies and `.env` are already prepared.
Otherwise, for this COMPLETE project cloned from GitHub:

```sh
composer install
```

Copy `env.example` to `.env`. Create an empty database named `tasks_today`.
Import `database/tasks_today.sql` into that selected database in phpMyAdmin.
Alternatively, after creating the database, use:

```sh
mysql -u root -p tasks_today < database/tasks_today.sql
```

Set database credentials, base URL, developer name, and section in `.env`.

```sh
php spark serve
```

Open http://localhost:8080/ . With XAMPP on Windows, if PHP is not on PATH,
use `C:\xampp\php\php.exe spark serve`.

## Manual installation from the source kit

The outer kit is an overlay; it is not the complete framework project.
From a terminal inside the extracted kit, run:

```sh
composer create-project codeigniter4/appstarter tasks-for-today --no-dev --prefer-dist
```

Copy all contents of `project/` into `tasks-for-today/`, merging folders and
replacing the included Routes.php and README.md. Copy env.example to .env
inside tasks-for-today. Then follow the database setup above.

## Verify before submission

On the day the SQL file is imported:

1. Welcome displays 4 tasks: 1 completed and 3 remaining (including in progress).
2. Task List displays all 9 records: 3 yesterday, 4 today, and 2 tomorrow.
3. Task List is sorted chronologically; check IDs 1 through 9.
4. Profile displays Alex Santos, demo_user, alex.santos@example.com and created date.
5. About displays your full name and section; all four navigation links work.
6. Check the same pages on the hosted URL.

Today changes at midnight Philippine time. Stored task dates do not move
automatically. An empty dashboard on later dates is correct behavior.
If you need fresh sample dates for a later demonstration, manually run
`database/refresh_demo_dates.sql`. It shifts all dates together and preserves
spacing. It does not delete data. Import the main SQL only once into an empty DB.

Verification queries:

```sql
SET time_zone = '+08:00';
SELECT task_date, COUNT(*) AS total FROM tasks GROUP BY task_date ORDER BY task_date;
SELECT * FROM tasks WHERE task_date = CURDATE();
SELECT COUNT(*) AS users_total FROM users;
```

## GitHub submission

Upload/commit the COMPLETE generated tasks-for-today folder, including app/,
public/, writable/ placeholders, spark, composer.json, composer.lock,
env.example, README.md, and database/. Keep the starter .gitignore.
Do not commit .env or vendor/. Commit composer.lock to reproduce dependency versions.
Replace the developer and submission placeholders in this README.

## Hosting

Use PHP + MySQL/MariaDB hosting that supports the Composer-selected framework
requirements and URL rewriting. GitHub Pages cannot execute this application.
Exact control-panel steps depend on your hosting provider.

1. Deploy the same complete project as the GitHub repository.
2. Run `composer install --no-dev --optimize-autoloader` on the host, or upload
   the locally installed vendor directory when the host has no Composer.
3. Create the host's database and import database/tasks_today.sql there.
4. Create a private .env with the host's database credentials and:

```ini
CI_ENVIRONMENT = production
app.baseURL = 'https://YOUR-DOMAIN/'
app.indexPage = ''
app.appTimezone = 'Asia/Manila'
developer.name = 'YOUR FULL NAME'
developer.section = 'YOUR SECTION'
```

5. Set the website document root to the project's public/ directory. The app/,
   vendor/, writable/, and .env files belong outside that public document root.
   Preserve public/.htaccess on Apache and enable rewrite support.
6. Make writable/ writable by the application process.
7. Verify all four routes over the real hosted URL and add both submission URLs here.

This kit was source-reviewed but not executed in its preparation environment,
which did not have PHP/MySQL. Perform the local and hosted checks above.

## Official documentation

- https://codeigniter4.github.io/userguide/installation/installing_composer.html
- https://codeigniter4.github.io/userguide/database/query_builder.html
- https://codeigniter4.github.io/userguide/installation/deployment.html
