@echo off
setlocal
cd /d "%~dp0"
if exist "C:\xampp\php\php.exe" set "PATH=C:\xampp\php;%PATH%"
where php >nul 2>nul
if errorlevel 1 (
 echo PHP was not found. Install XAMPP or add PHP to PATH, then retry.
 pause
 exit /b 1
)
where composer >nul 2>nul
if errorlevel 1 (
 echo Composer was not found. Install Composer, reopen this installer, and retry.
 pause
 exit /b 1
)
if exist "tasks-for-today" (
 echo The tasks-for-today folder already exists. No files were changed.
 echo Use that existing project. If installation failed, rename its folder and retry.
 pause
 exit /b 1
)
call composer create-project codeigniter4/appstarter tasks-for-today --no-dev --prefer-dist --no-interaction
if errorlevel 1 (
 echo Installation failed. Read the Composer error above.
 echo For an intl error: open C:\xampp\php\php.ini and remove the semicolon before extension=intl.
 echo For a zip error: enable extension=zip in the same file.
 pause
 exit /b 1
)
xcopy "project\*" "tasks-for-today\" /E /I /Y >nul
if errorlevel 1 (
 echo File copying failed. Do not use this incomplete installation.
 pause
 exit /b 1
)
copy "tasks-for-today\env.example" "tasks-for-today\.env" >nul
echo.
echo READY: your complete project is in tasks-for-today.
echo NEXT: follow START-HERE.txt to import the database and start the application.
pause
